const Google = {
    CLIENT_ID:
        "793997026296-41o4t0s8g78g5tp4osgd3puk77gom38k.apps.googleusercontent.com",
    CLIENT_SECRET: "GQgyl9rgWf0coiXa5DtRB-RL"
};

module.exports = Google;
